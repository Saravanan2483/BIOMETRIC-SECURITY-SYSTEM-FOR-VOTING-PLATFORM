Voting using Blockchain 

Work- Flow
1. Register the Candidate with his details
2. Register the Voters
3. Voters need to put their voterId to Vote for a candidate
4. Only the Owner of the Contract can check the Results for the election


Steps to use the app
Deploy the Contract of Voting
Put the Address of deployed contract in Voting.Js file.
Run the following two commands in VS Code terminal
npm install
npm start
