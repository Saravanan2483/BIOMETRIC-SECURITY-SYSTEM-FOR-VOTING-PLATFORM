import React from "react";
import Voting from "../components/Voting";

function Home() {
	return <Voting />;
}

export default Home;
